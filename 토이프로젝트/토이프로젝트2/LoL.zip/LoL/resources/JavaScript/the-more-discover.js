window.addEventListener('scroll', function () {
    d
    let scrollY = this.scrollY;
});